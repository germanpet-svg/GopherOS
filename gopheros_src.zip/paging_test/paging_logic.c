// paging_logic.c - La MISMA lógica de indexación/aislamiento que va a
// usar kernel/paging.c, extraída para poder testearla en el host con
// AddressSanitizer/UBSan antes de tocar el kernel freestanding.

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#define PTE_PRESENT  (1u << 0)
#define PTE_RW       (1u << 1)
#define PTE_US       (1u << 2)
#define IDENTITY_MAP_MB   32u
#define NUM_PAGE_TABLES    (IDENTITY_MAP_MB / 4)
#define PAGES_PER_TABLE    1024
#define PAGE_SIZE_4K       4096u
#define MAX_ADDR_SPACES    5

typedef struct {
    uint32_t directory[1024];
    uint32_t tables[NUM_PAGE_TABLES][PAGES_PER_TABLE];
    bool in_use;
} AddressSpace;

static AddressSpace kernel_space;
static AddressSpace proc_spaces[MAX_ADDR_SPACES];

static void fill_identity(AddressSpace* sp) {
    for (uint32_t pt = 0; pt < NUM_PAGE_TABLES; pt++) {
        for (uint32_t i = 0; i < PAGES_PER_TABLE; i++) {
            uint32_t phys = pt * 0x400000u + i * PAGE_SIZE_4K;
            sp->tables[pt][i] = phys | PTE_PRESENT | PTE_RW;
        }
        sp->directory[pt] = ((uint32_t)(uintptr_t)&sp->tables[pt]) | PTE_PRESENT | PTE_RW | PTE_US;
    }
    for (int i = NUM_PAGE_TABLES; i < 1024; i++) sp->directory[i] = 0;
}

void paging_init_test(void) {
    fill_identity(&kernel_space);
    for (int i = 0; i < MAX_ADDR_SPACES; i++) proc_spaces[i].in_use = false;
}

int paging_new_address_space(void) {
    for (int i = 0; i < MAX_ADDR_SPACES; i++) {
        if (!proc_spaces[i].in_use) {
            fill_identity(&proc_spaces[i]);
            proc_spaces[i].in_use = true;
            return i;
        }
    }
    return -1;
}

void paging_free_address_space(int handle) {
    if (handle < 0 || handle >= MAX_ADDR_SPACES) return;
    proc_spaces[handle].in_use = false;
}

static AddressSpace* space_for(int handle) {
    if (handle < 0 || handle >= MAX_ADDR_SPACES) return &kernel_space;
    return &proc_spaces[handle];
}

static void grant_in(AddressSpace* sp, uint32_t phys_start, uint32_t size, bool user) {
    uint32_t start_page = phys_start / PAGE_SIZE_4K;
    uint32_t end_page = (phys_start + size + PAGE_SIZE_4K - 1) / PAGE_SIZE_4K;
    for (uint32_t p = start_page; p < end_page; p++) {
        uint32_t pt_idx = p / PAGES_PER_TABLE;
        uint32_t pte_idx = p % PAGES_PER_TABLE;
        if (pt_idx >= NUM_PAGE_TABLES) break; // fuera de rango: no debe escribir nada (protegido con test abajo)
        if (user) sp->tables[pt_idx][pte_idx] |= PTE_US;
        else sp->tables[pt_idx][pte_idx] &= ~(uint32_t)PTE_US;
    }
}

void paging_grant_access(int handle, uint32_t phys_start, uint32_t size, bool user) {
    grant_in(space_for(handle), phys_start, size, user);
}

bool paging_is_user_accessible(int handle, uint32_t phys_addr) {
    AddressSpace* sp = space_for(handle);
    uint32_t p = phys_addr / PAGE_SIZE_4K;
    uint32_t pt_idx = p / PAGES_PER_TABLE;
    uint32_t pte_idx = p % PAGES_PER_TABLE;
    if (pt_idx >= NUM_PAGE_TABLES) return false;
    return (sp->tables[pt_idx][pte_idx] & PTE_US) != 0;
}

// ============================================================
// Tests
// ============================================================
static void test_isolation_between_processes(void) {
    paging_init_test();
    int a = paging_new_address_space();
    int b = paging_new_address_space();
    assert(a >= 0 && b >= 0 && a != b);

    uint32_t region_a = 0x200000; // 2MB
    uint32_t size = 0x1000;       // 4KB

    // Por defecto nadie tiene acceso
    assert(!paging_is_user_accessible(a, region_a));
    assert(!paging_is_user_accessible(b, region_a));

    // Le damos acceso a A sobre su propia region
    paging_grant_access(a, region_a, size, true);

    assert(paging_is_user_accessible(a, region_a));   // A si puede
    assert(!paging_is_user_accessible(b, region_a));  // B NO puede -- este es EL punto

    printf("OK: test_isolation_between_processes\n");
}

static void test_kernel_space_unaffected(void) {
    paging_init_test();
    int a = paging_new_address_space();
    uint32_t region = 0x300000;
    paging_grant_access(a, region, 0x1000, true);

    // El espacio de kernel (handle -1, compartido por procesos ring0) no
    // debe verse afectado por lo que le demos a un proceso ring3.
    assert(!paging_is_user_accessible(-1, region));
    printf("OK: test_kernel_space_unaffected\n");
}

static void test_revoke_access(void) {
    paging_init_test();
    int a = paging_new_address_space();
    uint32_t region = 0x400000;
    paging_grant_access(a, region, 0x1000, true);
    assert(paging_is_user_accessible(a, region));
    paging_grant_access(a, region, 0x1000, false);
    assert(!paging_is_user_accessible(a, region));
    printf("OK: test_revoke_access\n");
}

static void test_free_and_reuse_slot(void) {
    paging_init_test();
    int a = paging_new_address_space();
    paging_grant_access(a, 0x500000, 0x1000, true);
    paging_free_address_space(a);

    int c = paging_new_address_space(); // deberia reusar el mismo slot
    assert(c == a);
    // El slot reusado debe volver a estar limpio (sin el acceso anterior)
    assert(!paging_is_user_accessible(c, 0x500000));
    printf("OK: test_free_and_reuse_slot\n");
}

static void test_out_of_range_does_not_corrupt(void) {
    paging_init_test();
    int a = paging_new_address_space();
    // Pedir acceso a una direccion MUY fuera del identity-map (mas alla de
    // los 32MB) no debe escribir fuera de los arrays (ASan lo detectaria).
    paging_grant_access(a, 0xF0000000u, 0x2000, true);
    printf("OK: test_out_of_range_does_not_corrupt (sin overflow detectado por ASan)\n");
}

int main(void) {
    test_isolation_between_processes();
    test_kernel_space_unaffected();
    test_revoke_access();
    test_free_and_reuse_slot();
    test_out_of_range_does_not_corrupt();
    printf("\nTODOS LOS TESTS PASARON\n");
    return 0;
}
