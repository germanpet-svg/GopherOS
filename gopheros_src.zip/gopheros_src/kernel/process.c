// process.c - Scheduler cooperativo, máximo 5 procesos
//
// No hay timer interrupt que robe la CPU: el único mecanismo de scheduling
// es yield() explícito (o bloqueo en sleep_on). Esto elimina toda una clase
// de race conditions por preferir simplicidad sobre preemption real.

#include "types.h"
#include "hal.h"
#include "string.h"
#include "typesafe.h"
#include "vga.h"
#include "kresults.h"

#define MAX_PROCESSES 5
#define STACK_SIZE    (16 * 1024)

typedef enum {
    PROC_UNUSED,
    PROC_READY,
    PROC_RUNNING,
    PROC_BLOCKED,
    PROC_ZOMBIE,
} ProcState;

typedef struct Process {
    uint32_t pid;
    ProcState state;
    Region* region;
    uint32_t esp;
    char name[16];
    uint32_t jiffies_start;
    opt_u32_t blocked_on;
    bool is_ring3;
    void (*ring3_entry)(void);
    uint32_t ring3_user_stack;
    uint32_t ring3_kernel_stack_top; // para tss_set_kernel_stack() al conmutar a este proceso
    int addr_space; // handle de paging_new_address_space(); -1 = espacio de kernel (procesos ring0)
} Process;

static Process processes[MAX_PROCESSES];
static Process* current = NULL;
static uint32_t next_pid = 1;

// Solo para pruebas de aislamiento ring3-a-ring3 (ver ring3_demo_mem.c y
// gopheros_abi.h/gos_debug_get_arg): un valor que el kernel setea ANTES de
// crear un proceso, para poder "pasarle" una direccion sin tener IPC real.
static uint32_t debug_test_arg = 0;
void debug_set_test_arg(uint32_t v) { debug_test_arg = v; }
uint32_t debug_get_test_arg(void) { return debug_test_arg; }
static uint32_t idle_esp = 0; // "contexto" del arranque del kernel

extern void context_switch(uint32_t* old_esp_store, uint32_t new_esp);
extern volatile uint32_t jiffies;
void proc_exit(int code);

// ============================================================
// Crear proceso - entry es una función void(void) que nunca debería
// retornar (si retorna, el proceso termina automáticamente).
// ============================================================
proc_result_t proc_create(const char* name, void (*entry)(void)) {
    int slot = -1;
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (processes[i].state == PROC_UNUSED) { slot = i; break; }
    }
    if (slot < 0) {
        proc_result_t res = Err(GOS_EBUSY);
        return res;
    }

    Process* p = &processes[slot];
    p->region = region_new(STACK_SIZE + 4096);
    if (p->region == NULL) {
        proc_result_t res = Err(GOS_ENOMEM);
        return res;
    }

    uint8_t* stack_top = (uint8_t*)region_alloc(p->region, STACK_SIZE) + STACK_SIZE;

    // Layout esperado por context_switch (ver isr.s), de mayor a menor dirección:
    // ... [ret_eip=entry][saved_ebp][eax][ecx][edx][ebx][esp_dummy][ebp][esi][edi] <- esp
    // Al hacer popa+pop ebp+ret, la CPU "regresa" directamente a `entry`.
    uint32_t* sp = (uint32_t*)stack_top;
    sp -= 1; *sp = (uint32_t)entry;   // "ret" saltará aquí como si fuera llamado
    sp -= 1; *sp = 0;                 // saved ebp
    sp -= 1; *sp = 0;                 // eax
    sp -= 1; *sp = 0;                 // ecx
    sp -= 1; *sp = 0;                 // edx
    sp -= 1; *sp = 0;                 // ebx
    sp -= 1; *sp = 0;                 // esp dummy
    sp -= 1; *sp = 0;                 // ebp
    sp -= 1; *sp = 0;                 // esi
    sp -= 1; *sp = 0;                 // edi

    p->esp = (uint32_t)sp;
    p->pid = next_pid++;
    p->state = PROC_READY;
    p->jiffies_start = jiffies;
    p->blocked_on = (opt_u32_t)None;
    p->is_ring3 = false;
    p->addr_space = -1;
    strncpy(p->name, name, 16);

    proc_result_t res = Ok(p);
    return res;
}

// ============================================================
// proc_create_ring3() - Crea un proceso que corre en CPL3 (ring 3).
//
// Primer corte: hay dos stacks (una chica de kernel, solo para el
// trampolín inicial + futuras interrupciones/syscalls vía la TSS; y la de
// usuario, donde corre `entry`). Ver paging.c: por ahora TODA la memoria
// identity-mapeada es accesible desde ring3 (sin aislacion fina todavia),
// asi que esto prueba la transicion de privilegio y el manejo de fallos,
// no aislacion de memoria real.
// ============================================================
static void ring3_trampoline(void) {
    extern void enter_ring3(uint32_t entry_eip, uint32_t user_esp);
    Process* p = current; // "current" ya apunta a este proceso (recien planificado)
    enter_ring3((uint32_t)p->ring3_entry, p->ring3_user_stack);
    for (;;) cpu_halt(); // enter_ring3 no deberia retornar jamas
}

proc_result_t proc_create_ring3(const char* name, void (*entry)(void), size_t user_stack_size) {
    int slot = -1;
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (processes[i].state == PROC_UNUSED) { slot = i; break; }
    }
    if (slot < 0) {
        proc_result_t res = Err(GOS_EBUSY);
        return res;
    }

    Process* p = &processes[slot];
    size_t kstack_size = 4096;
    p->region = region_new(kstack_size + user_stack_size + 8192);
    if (p->region == NULL) {
        proc_result_t res = Err(GOS_ENOMEM);
        return res;
    }

    uint8_t* kstack_top = (uint8_t*)region_alloc(p->region, kstack_size) + kstack_size;
    uint8_t* ustack_top = (uint8_t*)region_alloc(p->region, user_stack_size) + user_stack_size;

    uint32_t* sp = (uint32_t*)kstack_top;
    sp -= 1; *sp = (uint32_t)ring3_trampoline; // "ret" saltara aca (en CPL0 todavia)
    sp -= 1; *sp = 0;  // saved ebp
    sp -= 1; *sp = 0;  // eax
    sp -= 1; *sp = 0;  // ecx
    sp -= 1; *sp = 0;  // edx
    sp -= 1; *sp = 0;  // ebx
    sp -= 1; *sp = 0;  // esp dummy
    sp -= 1; *sp = 0;  // ebp
    sp -= 1; *sp = 0;  // esi
    sp -= 1; *sp = 0;  // edi

    p->esp = (uint32_t)sp;
    p->pid = next_pid++;
    p->state = PROC_READY;
    p->jiffies_start = jiffies;
    p->blocked_on = (opt_u32_t)None;
    p->is_ring3 = true;
    p->ring3_entry = entry;
    p->ring3_user_stack = (uint32_t)ustack_top;
    p->ring3_kernel_stack_top = (uint32_t)kstack_top;
    strncpy(p->name, name, 16);

    // Este proceso corre en CPL3 en SU PROPIO espacio de direcciones (no
    // el compartido): su región de memoria (stack de kernel para el
    // trampolín + stack de usuario) gana el bit US=1 solo AHI. Otro
    // proceso ring3, con su propio espacio, ni siquiera tiene esta región
    // mapeada como accesible — no es "permiso denegado", es que no existe
    // para el. Esto es lo que da aislamiento entre procesos, no solo
    // entre kernel y procesos (ver paging.c).
    extern phys_addr_t region_backing_phys(Region* r);
    extern size_t region_backing_size(Region* r);
    extern int paging_new_address_space(void);
    extern void paging_grant_access(int handle, uint32_t phys_start, uint32_t size, bool user_accessible);

    int space = paging_new_address_space();
    if (space < 0) {
        region_destroy(p->region);
        proc_result_t res = Err(GOS_ENOMEM);
        return res;
    }
    p->addr_space = space;
    paging_grant_access(space, region_backing_phys(p->region), (uint32_t)region_backing_size(p->region), true);

    proc_result_t res = Ok(p);
    return res;
}

// Llamado (indirectamente, ver idt.c) cuando un proceso ring3 provoca una
// excepcion de CPU. Para cuando esto se ejecuta, la CPU ya volvio a CPL0
// de forma normal (iret con el mismo privilegio), asi que es seguro llamar
// a las funciones normales del scheduler ac
_Noreturn void kernel_reap_current_process(void) {
    vga_set_color(VGA_YELLOW, VGA_BLACK);
    vga_puts("[ring3] proceso terminado por fallo, el resto del sistema sigue vivo.\n");
    proc_exit(-1);
    for (;;) cpu_halt(); // no deberia llegar aca
}

void proc_exit(int code) {
    (void)code;
    if (current == NULL) return;
    if (current->is_ring3) {
        extern void paging_free_address_space(int handle);
        paging_free_address_space(current->addr_space);
        current->addr_space = -1;
    }
    current->state = PROC_ZOMBIE;
    extern void proc_yield(void);
    proc_yield();
    for (;;) cpu_halt(); // nunca debería llegar aquí
}

const char* proc_current_name(void) {
    return current ? current->name : "kernel";
}

uint32_t proc_current_pid(void) {
    return current ? current->pid : 0;
}

// Snapshot de los procesos para 'ps'. state: 0=libre 1=listo 2=corriendo
// 3=bloqueado 4=zombi. Devuelve cuántas entradas escribió.
int proc_list(uint32_t* pids, char names[][16], int* states, int max) {
    int n = 0;
    for (int i = 0; i < MAX_PROCESSES && n < max; i++) {
        if (processes[i].state == PROC_UNUSED) continue;
        pids[n] = processes[i].pid;
        strncpy(names[n], processes[i].name, 16);
        states[n] = (int)processes[i].state;
        n++;
    }
    return n;
}

// ============================================================
// yield() - Cede la CPU voluntariamente al siguiente READY.
// Si nadie está READY pero hay procesos BLOCKED (esperando IRQ,
// como el teclado), entra en espera de bajo consumo (sti;hlt) hasta
// la próxima interrupción y reintenta — nunca "apaga" el sistema
// mientras haya algo por lo que valga la pena seguir esperando.
// ============================================================
void proc_yield(void) {
    extern void irq_run_bottom_halves(void);

    for (;;) {
        irq_run_bottom_halves();

        int start_idx = current ? (int)(current - processes) : -1;

        for (int i = 1; i <= MAX_PROCESSES; i++) {
            int idx = (start_idx + i) % MAX_PROCESSES;
            if (processes[idx].state == PROC_READY) {
                Process* prev = current;
                current = &processes[idx];
                current->state = PROC_RUNNING;
                if (prev && prev != current && prev->state == PROC_RUNNING) prev->state = PROC_READY;

                extern void paging_switch_address_space(int handle);
                paging_switch_address_space(current->addr_space);
                if (current->is_ring3) {
                    extern void tss_set_kernel_stack(uint32_t esp0);
                    tss_set_kernel_stack(current->ring3_kernel_stack_top);
                }

                uint32_t* old_store = prev ? &prev->esp : &idle_esp;
                context_switch(old_store, current->esp);
                return;
            }
        }

        // Nadie más READY: si el actual sigue vivo (no se bloqueó), sigue corriendo.
        if (current && current->state == PROC_RUNNING) return;

        // ¿Queda algo vivo (bloqueado, esperando teclado/timer/etc)?
        bool any_alive = false;
        for (int i = 0; i < MAX_PROCESSES; i++) {
            if (processes[i].state == PROC_BLOCKED || processes[i].state == PROC_READY) {
                any_alive = true;
                break;
            }
        }
        if (!any_alive) {
            vga_puts("\n[scheduler] No hay procesos listos. Sistema detenido.\n");
            for (;;) cpu_halt();
        }

        // Nada que hacer ahora mismo: dormir la CPU hasta la próxima IRQ
        // (sti+hlt es atómico en x86: no se puede perder la interrupción
        // entre habilitar y dormir) y reintentar desde el principio.
        __asm__ volatile ("sti; hlt");
    }
}

void proc_sleep_on(uint32_t event_id) {
    if (current == NULL) return;
    current->state = PROC_BLOCKED;
    current->blocked_on = (opt_u32_t) Some(event_id);
    proc_yield();
}

void proc_wakeup(uint32_t event_id) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (processes[i].state == PROC_BLOCKED &&
            processes[i].blocked_on.is_some &&
            processes[i].blocked_on.value == event_id) {
            processes[i].state = PROC_READY;
            processes[i].blocked_on = (opt_u32_t)None;
        }
    }
}

// ============================================================
// scheduler_run() - Arranca el scheduling, nunca retorna
// ============================================================
_Noreturn void scheduler_run(void) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (processes[i].state == PROC_READY) {
            current = &processes[i];
            current->state = PROC_RUNNING;
            extern void paging_switch_address_space(int handle);
            paging_switch_address_space(current->addr_space);
            if (current->is_ring3) {
                extern void tss_set_kernel_stack(uint32_t esp0);
                tss_set_kernel_stack(current->ring3_kernel_stack_top);
            }
            context_switch(&idle_esp, current->esp);
            break;
        }
    }
    // Si algún proceso hace yield() y vuelve aquí (no debería en este diseño),
    // mantenemos la CPU ocupada de forma segura.
    for (;;) {
        proc_yield();
        cpu_halt();
    }
}
