// ============================================================
// gopherpy.h - Public API for GopherPy translator
// ============================================================

#ifndef GOPHERPY_H
#define GOPHERPY_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================
// ERROR HANDLING
// ============================================================
void gp_error(const char* fmt, ...);
const char* gp_get_error(void);

// ============================================================
// BINDINGS TABLE
// ============================================================

typedef struct {
    const char* py_name;      // Python name: "mem_free", "fs.ls"
    const char* c_name;       // C function: "sys_mem_free", "sys_fs_ls"
    const char* ret_type;     // Return type: "uint32_t", "void", "Option<...>"
    const char* arg_types[8]; // Argument types
    int nargs;                // -1 = variadic
    const char* doc;          // Documentation
} GPBinding;

// Kernel API bindings (defined in gopherpy.c)
extern GPBinding bindings[];

GPBinding* gp_find_binding(const char* name);

// ============================================================
// COMPILER API
// ============================================================

/**
 * Compile Python source to C code
 * 
 * @param python_source  Input Python code
 * @param c_output       Output buffer for generated C
 * @param c_size         Size of output buffer
 * @return               Number of bytes written, or -1 on error
 */
int gp_compile(const char* python_source, char* c_output, size_t c_size);

/**
 * Validate AST against whitelist
 */
typedef struct ASTNode ASTNode;
bool gp_validate_ast(ASTNode* ast);

// ============================================================
// RUNTIME TYPES (used by generated C code)
// ============================================================

typedef struct {
    void** items;
    size_t len;
    size_t capacity;
} GP_List;

typedef struct {
    char* key;
    void* value;
} GP_DictEntry;

typedef struct {
    GP_DictEntry* entries;
    size_t len;
} GP_Dict;

typedef struct {
    enum { GP_INT, GP_STR, GP_LIST, GP_DICT, GP_BOOL, GP_NONE } type;
    union {
        int i;
        char* s;
        GP_List* l;
        GP_Dict* d;
        bool b;
    };
} GP_Any;

// ============================================================
// KERNEL API STUBS (implemented by kernel)
// These are called by generated C code
// ============================================================

// Memory
uint32_t sys_mem_free(void);
uint32_t sys_mem_total(void);
uint32_t sys_mem_used(void);

// Filesystem
typedef struct { char name[64]; uint32_t size; } GP_FileInfo;
GP_List* sys_fs_ls(const char* path);
char* sys_fs_read(const char* path);
int sys_fs_write(const char* path, const char* data);
int sys_fs_mkdir(const char* path);

// Gopher
typedef struct { char type; char name[64]; char selector[128]; } GP_GopherItem;
void* sys_gopher_menu_new(void);
void sys_gopher_menu_add(void* menu, const char* type, const char* name, const char* selector);
GP_List* sys_gopher_fetch(const char* host, int port, const char* selector);
int sys_gopher_serve(void* menu, int port);

// Network
bool sys_net_ping(const char* host);
GP_Dict* sys_net_ifconfig(void);

// AI
char* sys_oracle_ask(const char* question);

// System
void sys_print(const char* msg);
void sys_print_int(int n);
void sys_reboot(void);
void sys_halt(void);

// Region allocator (passed to generated code)
typedef struct Region Region;

#ifdef __cplusplus
}
#endif

#endif // GOPHERPY_H
