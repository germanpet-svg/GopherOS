// ============================================================
// gopherpy.c - Traductor Python → C nativo para GopherOS
// Version: 1.0
// Size: ~1500 lines
// Purpose: Users write Python-familiar syntax, kernel runs C native
// ============================================================

#include "gopherpy.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

// ============================================================
// CONFIGURATION
// ============================================================
#define GP_MAX_LINE_LEN     256
#define GP_MAX_TOKENS       4096
#define GP_MAX_AST_NODES    4096
#define GP_MAX_BLOCK_STMTS  64
#define GP_MAX_INDENT       32
#define GP_MAX_OUTPUT       8192
#define GP_MAX_BINDINGS     64
#define GP_MAX_STRINGS      32

// ============================================================
// TOKENIZER
// ============================================================

typedef enum {
    TOK_EOF = 0,
    TOK_NEWLINE,
    TOK_INDENT,
    TOK_DEDENT,
    TOK_IDENT,
    TOK_NUMBER,
    TOK_STRING,
    TOK_LPAREN,     // (
    TOK_RPAREN,     // )
    TOK_LBRACKET,   // [
    TOK_RBRACKET,   // ]
    TOK_LBRACE,     // {
    TOK_RBRACE,     // }
    TOK_COMMA,      // ,
    TOK_DOT,        // .
    TOK_COLON,      // :
    TOK_ASSIGN,     // =
    TOK_EQ,         // ==
    TOK_NE,         // !=
    TOK_LT,         // <
    TOK_GT,         // >
    TOK_LE,         // <=
    TOK_GE,         // >=
    TOK_PLUS,       // +
    TOK_MINUS,      // -
    TOK_MUL,        // *
    TOK_DIV,        // /
    TOK_MOD,        // %
    TOK_AND,        // and
    TOK_OR,         // or
    TOK_NOT,        // not
    TOK_IF,
    TOK_ELSE,
    TOK_ELIF,
    TOK_FOR,
    TOK_IN,
    TOK_WHILE,
    TOK_TRUE,
    TOK_FALSE,
    TOK_NONE,
    TOK_RETURN,
    TOK_PASS,
    TOK_BREAK,
    TOK_CONTINUE,
} GP_TokenType;

typedef struct {
    GP_TokenType type;
    char text[GP_MAX_LINE_LEN];
    int line;
    int col;
} GP_Token;

typedef struct {
    const char* source;
    int pos;
    int line;
    int col;
    GP_Token tokens[GP_MAX_TOKENS];
    int num_tokens;
} GP_Lexer;

// Keywords table
static struct {
    const char* word;
    GP_TokenType type;
} keywords[] = {
    {"and", TOK_AND}, {"or", TOK_OR}, {"not", TOK_NOT},
    {"if", TOK_IF}, {"else", TOK_ELSE}, {"elif", TOK_ELIF},
    {"for", TOK_FOR}, {"in", TOK_IN}, {"while", TOK_WHILE},
    {"True", TOK_TRUE}, {"False", TOK_FALSE}, {"None", TOK_NONE},
    {"return", TOK_RETURN}, {"pass", TOK_PASS},
    {"break", TOK_BREAK}, {"continue", TOK_CONTINUE},
    {NULL, TOK_EOF}
};

static bool gp_is_alpha(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
}

static bool gp_is_digit(char c) {
    return c >= '0' && c <= '9';
}

static bool gp_is_alnum(char c) {
    return gp_is_alpha(c) || gp_is_digit(c);
}

static bool gp_is_space(char c) {
    return c == ' ' || c == '\t' || c == '\r';
}

static char gp_peek(GP_Lexer* lex) {
    return lex->source[lex->pos];
}

static char gp_advance(GP_Lexer* lex) {
    char c = lex->source[lex->pos];
    if (c == '\n') {
        lex->line++;
        lex->col = 0;
    } else {
        lex->col++;
    }
    lex->pos++;
    return c;
}

static void gp_add_token(GP_Lexer* lex, GP_TokenType type, const char* text) {
    if (lex->num_tokens >= GP_MAX_TOKENS) {
        gp_error("Too many tokens");
        return;
    }
#ifdef GP_DEBUG_TOKENS
    fprintf(stderr, "TOKEN[%d] type=%d text='%s'\n", lex->num_tokens, type, text);
#endif
    GP_Token* t = &lex->tokens[lex->num_tokens++];
    t->type = type;
    t->line = lex->line;
    t->col = lex->col;
    strncpy(t->text, text, GP_MAX_LINE_LEN - 1);
    t->text[GP_MAX_LINE_LEN - 1] = '\0';
}

static GP_TokenType gp_keyword_type(const char* word) {
    for (int i = 0; keywords[i].word; i++) {
        if (strcmp(word, keywords[i].word) == 0) {
            return keywords[i].type;
        }
    }
    return TOK_IDENT;
}

static void gp_lex_string(GP_Lexer* lex, char quote) {
    char str[GP_MAX_LINE_LEN];
    int i = 0;
    
    gp_advance(lex); // consume opening quote
    
    while (gp_peek(lex) != quote && gp_peek(lex) != '\0') {
        if (i >= GP_MAX_LINE_LEN - 1) break;
        str[i++] = gp_advance(lex);
    }
    
    str[i] = '\0';
    
    if (gp_peek(lex) == quote) {
        gp_advance(lex); // consume closing quote
    }
    
    gp_add_token(lex, TOK_STRING, str);
}

static void gp_lex_number(GP_Lexer* lex) {
    char num[32];
    int i = 0;
    
    while (gp_is_digit(gp_peek(lex)) && i < 31) {
        num[i++] = gp_advance(lex);
    }
    
    // Decimal part
    if (gp_peek(lex) == '.') {
        num[i++] = gp_advance(lex);
        while (gp_is_digit(gp_peek(lex)) && i < 31) {
            num[i++] = gp_advance(lex);
        }
    }
    
    num[i] = '\0';
    gp_add_token(lex, TOK_NUMBER, num);
}

static void gp_lex_ident(GP_Lexer* lex) {
    char ident[GP_MAX_LINE_LEN];
    int i = 0;
    
    while (gp_is_alnum(gp_peek(lex)) && i < GP_MAX_LINE_LEN - 1) {
        ident[i++] = gp_advance(lex);
    }
    
    ident[i] = '\0';
    GP_TokenType type = gp_keyword_type(ident);
    gp_add_token(lex, type, ident);
}

static void gp_skip_comment(GP_Lexer* lex) {
    while (gp_peek(lex) != '\n' && gp_peek(lex) != '\0') {
        gp_advance(lex);
    }
}

int gp_tokenize(const char* source, GP_Token* out_tokens, int max_tokens) {
    static GP_Lexer lex;
    lex.source = source;
    lex.pos = 0;
    lex.line = 1;
    lex.col = 0;
    lex.num_tokens = 0;
    
    int indent_stack[GP_MAX_INDENT];
    int indent_level = 0;
    indent_stack[0] = 0;
    
    bool at_line_start = true;
    
    while (gp_peek(&lex) != '\0') {
        char c = gp_peek(&lex);
        
        // Comments
        if (c == '#') {
            gp_skip_comment(&lex);
            continue;
        }
        
        // Newlines
        if (c == '\n') {
            gp_advance(&lex);
            gp_add_token(&lex, TOK_NEWLINE, "\\n");
            at_line_start = true;
            continue;
        }
        
        // Indentation handling: se evalúa SIEMPRE al inicio de línea, incluso
        // si la línea empieza directamente en columna 0 (sin espacios) — ese
        // es justo el caso que cierra un bloque (DEDENT) y antes se ignoraba,
        // desincronizando el parser con cualquier bloque if/for/while seguido
        // de una línea sin indentar (else, o el siguiente statement top-level).
        if (at_line_start) {
            int spaces = 0;
            while (gp_is_space(gp_peek(&lex))) {
                gp_advance(&lex);
                spaces++;
            }

            // Línea en blanco o solo comentario: no afecta la pila de indentación.
            if (gp_peek(&lex) == '\n' || gp_peek(&lex) == '#' || gp_peek(&lex) == '\0') {
                continue;
            }

            if (spaces > indent_stack[indent_level]) {
                indent_stack[++indent_level] = spaces;
                gp_add_token(&lex, TOK_INDENT, "INDENT");
            } else if (spaces < indent_stack[indent_level]) {
                while (indent_level > 0 && spaces < indent_stack[indent_level]) {
                    indent_level--;
                    gp_add_token(&lex, TOK_DEDENT, "DEDENT");
                }
                if (spaces != indent_stack[indent_level]) {
                    gp_error("Inconsistent indentation");
                    return -1;
                }
            }
            at_line_start = false;
            continue;
        }
        
        if (gp_is_space(c)) {
            gp_advance(&lex);
            continue;
        }
        
        at_line_start = false;
        
        // Strings
        if (c == '"' || c == '\'') {
            gp_lex_string(&lex, c);
            continue;
        }
        
        // Numbers
        if (gp_is_digit(c)) {
            gp_lex_number(&lex);
            continue;
        }
        
        // Identifiers
        if (gp_is_alpha(c)) {
            gp_lex_ident(&lex);
            continue;
        }
        
        // Two-character operators
        char next = lex.source[lex.pos + 1];
        if (c == '=' && next == '=') { gp_advance(&lex); gp_advance(&lex); gp_add_token(&lex, TOK_EQ, "=="); continue; }
        if (c == '!' && next == '=') { gp_advance(&lex); gp_advance(&lex); gp_add_token(&lex, TOK_NE, "!="); continue; }
        if (c == '<' && next == '=') { gp_advance(&lex); gp_advance(&lex); gp_add_token(&lex, TOK_LE, "<="); continue; }
        if (c == '>' && next == '=') { gp_advance(&lex); gp_advance(&lex); gp_add_token(&lex, TOK_GE, ">="); continue; }
        
        // Single-character tokens
        gp_advance(&lex);
        char single[2] = {c, '\0'};
        switch (c) {
            case '(': gp_add_token(&lex, TOK_LPAREN, single); break;
            case ')': gp_add_token(&lex, TOK_RPAREN, single); break;
            case '[': gp_add_token(&lex, TOK_LBRACKET, single); break;
            case ']': gp_add_token(&lex, TOK_RBRACKET, single); break;
            case '{': gp_add_token(&lex, TOK_LBRACE, single); break;
            case '}': gp_add_token(&lex, TOK_RBRACE, single); break;
            case ',': gp_add_token(&lex, TOK_COMMA, single); break;
            case '.': gp_add_token(&lex, TOK_DOT, single); break;
            case ':': gp_add_token(&lex, TOK_COLON, single); break;
            case '=': gp_add_token(&lex, TOK_ASSIGN, single); break;
            case '<': gp_add_token(&lex, TOK_LT, single); break;
            case '>': gp_add_token(&lex, TOK_GT, single); break;
            case '+': gp_add_token(&lex, TOK_PLUS, single); break;
            case '-': gp_add_token(&lex, TOK_MINUS, single); break;
            case '*': gp_add_token(&lex, TOK_MUL, single); break;
            case '/': gp_add_token(&lex, TOK_DIV, single); break;
            case '%': gp_add_token(&lex, TOK_MOD, single); break;
            default:
                gp_error("Unknown character: %c", c);
                return -1;
        }
    }
    
    // Dedent remaining
    while (indent_level > 0) {
        indent_level--;
        gp_add_token(&lex, TOK_DEDENT, "DEDENT");
    }
    
    gp_add_token(&lex, TOK_EOF, "EOF");
    
    // Copy to output
    int n = lex.num_tokens;
    if (n > max_tokens) n = max_tokens;
    memcpy(out_tokens, lex.tokens, n * sizeof(GP_Token));
    
    return n;
}

// ============================================================
// AST - ABSTRACT SYNTAX TREE
// ============================================================

typedef enum {
    AST_PROGRAM,
    AST_EXPR_STMT,
    AST_ASSIGN,
    AST_IF,
    AST_FOR,
    AST_WHILE,
    AST_CALL,
    AST_METHOD,
    AST_BINOP,
    AST_UNOP,
    AST_VAR,
    AST_CONST,
    AST_LIST,
    AST_DICT,
    AST_INDEX,
    AST_RETURN,
    AST_PASS,
    AST_BREAK,
    AST_CONTINUE,
} AST_Type;

typedef struct ASTNode {
    AST_Type type;
    int line;
    bool is_string_const; // discrimina AST_CONST: true=string.str, false=number.val
                          // (number y string comparten memoria via union abajo,
                          // asi que NO se puede usar string.str[0] como bandera)
    union {
        struct { struct ASTNode* stmts[GP_MAX_BLOCK_STMTS]; int n_stmts; } program;
        struct { char name[64]; struct ASTNode* args[8]; int nargs; } call;
        struct { struct ASTNode* obj; char method[64]; struct ASTNode* args[8]; int nargs; } method;
        struct { char name[64]; struct ASTNode* value; } assign;
        struct { struct ASTNode* cond; struct ASTNode* then_stmts[GP_MAX_BLOCK_STMTS]; int n_then; struct ASTNode* else_stmts[GP_MAX_BLOCK_STMTS]; int n_else; } if_stmt;
        struct { char var[64]; struct ASTNode* iterable; struct ASTNode* body[GP_MAX_BLOCK_STMTS]; int n_body; } for_stmt;
        struct { struct ASTNode* cond; struct ASTNode* body[GP_MAX_BLOCK_STMTS]; int n_body; } while_stmt;
        struct { struct ASTNode* left; char op[4]; struct ASTNode* right; } binop;
        struct { char op[4]; struct ASTNode* operand; } unop;
        struct { char name[64]; } var;
        struct { char str[256]; } string;
        struct { int val; } number;
        struct { struct ASTNode* items[16]; int n_items; } list;
        struct { struct ASTNode** keys; struct ASTNode** vals; int n_items; } dict;
        struct { struct ASTNode* obj; struct ASTNode* index; } index;
        struct { struct ASTNode* value; } ret;
    };
} ASTNode;

static ASTNode ast_pool[GP_MAX_AST_NODES];
static int ast_pool_used = 0;

static ASTNode* ast_alloc(AST_Type type, int line) {
    if (ast_pool_used >= GP_MAX_AST_NODES) {
        gp_error("AST pool exhausted");
        return NULL;
    }
    ASTNode* n = &ast_pool[ast_pool_used++];
    memset(n, 0, sizeof(ASTNode));
    n->type = type;
    n->line = line;
    return n;
}

static void ast_reset(void) {
    ast_pool_used = 0;
}

// ============================================================
// PARSER
// ============================================================

typedef struct {
    GP_Token* tokens;
    int num_tokens;
    int pos;
} GP_Parser;

static GP_Token* gp_peek_tok(GP_Parser* p) {
    if (p->pos >= p->num_tokens) return &p->tokens[p->num_tokens - 1];
    return &p->tokens[p->pos];
}

static GP_Token* gp_advance_tok(GP_Parser* p) {
    if (p->pos >= p->num_tokens) return &p->tokens[p->num_tokens - 1];
    return &p->tokens[p->pos++];
}

static bool gp_match(GP_Parser* p, GP_TokenType type) {
    return gp_peek_tok(p)->type == type;
}

static bool gp_consume(GP_Parser* p, GP_TokenType type) {
    if (gp_match(p, type)) {
        gp_advance_tok(p);
        return true;
    }
    return false;
}

static bool gp_expect(GP_Parser* p, GP_TokenType type, const char* msg) {
    if (!gp_consume(p, type)) {
        gp_error("Line %d: expected %s, got %s",
                 gp_peek_tok(p)->line, msg, gp_peek_tok(p)->text);
        return false;
    }
    return true;
}

static ASTNode* gp_parse_expr(GP_Parser* p);
static ASTNode* gp_parse_stmt(GP_Parser* p);
static ASTNode* gp_parse_block(GP_Parser* p);

static ASTNode* gp_parse_atom(GP_Parser* p) {
    GP_Token* t = gp_peek_tok(p);
    
    if (t->type == TOK_NUMBER) {
        gp_advance_tok(p);
        ASTNode* n = ast_alloc(AST_CONST, t->line);
        n->is_string_const = false;
        n->number.val = atoi(t->text);
        return n;
    }
    
    if (t->type == TOK_STRING) {
        gp_advance_tok(p);
        ASTNode* n = ast_alloc(AST_CONST, t->line);
        n->is_string_const = true;
        strncpy(n->string.str, t->text, 255);
        return n;
    }
    
    if (t->type == TOK_TRUE || t->type == TOK_FALSE) {
        gp_advance_tok(p);
        ASTNode* n = ast_alloc(AST_CONST, t->line);
        n->is_string_const = false;
        n->number.val = (t->type == TOK_TRUE) ? 1 : 0;
        return n;
    }
    
    if (t->type == TOK_NONE) {
        gp_advance_tok(p);
        ASTNode* n = ast_alloc(AST_CONST, t->line);
        n->is_string_const = false;
        n->number.val = 0;
        return n;
    }
    
    if (t->type == TOK_IDENT) {
        gp_advance_tok(p);
        ASTNode* n = ast_alloc(AST_VAR, t->line);
        strncpy(n->var.name, t->text, 63);
        
        // Method call: obj.method(args)
        if (gp_consume(p, TOK_DOT)) {
            GP_Token* method = gp_peek_tok(p);
            if (method->type != TOK_IDENT) {
                gp_error("Line %d: expected method name after '.'", method->line);
                return NULL;
            }
            gp_advance_tok(p);
            
            ASTNode* m = ast_alloc(AST_METHOD, t->line);
            m->method.obj = n;
            strncpy(m->method.method, method->text, 63);
            
            if (!gp_expect(p, TOK_LPAREN, "'('")) return NULL;
            
            // Parse arguments
            m->method.nargs = 0;
            
            if (!gp_match(p, TOK_RPAREN)) {
                while (1) {
                    ASTNode* arg = gp_parse_expr(p);
                    if (!arg) return NULL;
                    if (m->method.nargs < 8) m->method.args[m->method.nargs++] = arg;
                    if (!gp_consume(p, TOK_COMMA)) break;
                }
            }
            
            if (!gp_expect(p, TOK_RPAREN, "')'")) return NULL;
            return m;
        }
        
        // Function call: func(args)
        if (gp_consume(p, TOK_LPAREN)) {
            ASTNode* call = ast_alloc(AST_CALL, t->line);
            strncpy(call->call.name, n->var.name, 63);
            
            call->call.nargs = 0;
            
            if (!gp_match(p, TOK_RPAREN)) {
                // Parse arguments
                while (1) {
                    ASTNode* arg = gp_parse_expr(p);
                    if (!arg) return NULL;
                    if (call->call.nargs < 8) call->call.args[call->call.nargs++] = arg;
                    if (!gp_consume(p, TOK_COMMA)) break;
                }
            }
            
            if (!gp_expect(p, TOK_RPAREN, "')'")) return NULL;
            return call;
        }
        
        // Index: obj[index]
        if (gp_consume(p, TOK_LBRACKET)) {
            ASTNode* idx = ast_alloc(AST_INDEX, t->line);
            idx->index.obj = n;
            idx->index.index = gp_parse_expr(p);
            if (!gp_expect(p, TOK_RBRACKET, "']'")) return NULL;
            return idx;
        }
        
        return n;
    }
    
    if (t->type == TOK_LPAREN) {
        gp_advance_tok(p);
        ASTNode* expr = gp_parse_expr(p);
        if (!gp_expect(p, TOK_RPAREN, "')'")) return NULL;
        return expr;
    }
    
    if (t->type == TOK_LBRACKET) {
        gp_advance_tok(p);
        ASTNode* list = ast_alloc(AST_LIST, t->line);
        list->list.n_items = 0;
        
        if (!gp_match(p, TOK_RBRACKET)) {
            while (1) {
                ASTNode* item = gp_parse_expr(p);
                if (!item) return NULL;
                if (list->list.n_items < 16) list->list.items[list->list.n_items++] = item;
                if (!gp_consume(p, TOK_COMMA)) break;
            }
        }
        
        if (!gp_expect(p, TOK_RBRACKET, "']'")) return NULL;
        return list;
    }
    
    gp_error("Line %d: unexpected token '%s'", t->line, t->text);
    return NULL;
}

static ASTNode* gp_parse_unary(GP_Parser* p) {
    if (gp_consume(p, TOK_MINUS) || gp_consume(p, TOK_NOT)) {
        GP_Token* op = &p->tokens[p->pos - 1];
        ASTNode* n = ast_alloc(AST_UNOP, op->line);
        strncpy(n->unop.op, op->text, 3);
        n->unop.operand = gp_parse_unary(p);
        return n;
    }
    return gp_parse_atom(p);
}

static ASTNode* gp_parse_muldiv(GP_Parser* p) {
    ASTNode* left = gp_parse_unary(p);
    if (!left) return NULL;
    
    while (gp_match(p, TOK_MUL) || gp_match(p, TOK_DIV) || gp_match(p, TOK_MOD)) {
        GP_Token* op = gp_advance_tok(p);
        ASTNode* right = gp_parse_unary(p);
        if (!right) return NULL;
        
        ASTNode* bin = ast_alloc(AST_BINOP, op->line);
        strncpy(bin->binop.op, op->text, 3);
        bin->binop.left = left;
        bin->binop.right = right;
        left = bin;
    }
    
    return left;
}

static ASTNode* gp_parse_addsub(GP_Parser* p) {
    ASTNode* left = gp_parse_muldiv(p);
    if (!left) return NULL;
    
    while (gp_match(p, TOK_PLUS) || gp_match(p, TOK_MINUS)) {
        GP_Token* op = gp_advance_tok(p);
        ASTNode* right = gp_parse_muldiv(p);
        if (!right) return NULL;
        
        ASTNode* bin = ast_alloc(AST_BINOP, op->line);
        strncpy(bin->binop.op, op->text, 3);
        bin->binop.left = left;
        bin->binop.right = right;
        left = bin;
    }
    
    return left;
}

static ASTNode* gp_parse_cmp(GP_Parser* p) {
    ASTNode* left = gp_parse_addsub(p);
    if (!left) return NULL;
    
    while (gp_match(p, TOK_EQ) || gp_match(p, TOK_NE) || 
           gp_match(p, TOK_LT) || gp_match(p, TOK_GT) ||
           gp_match(p, TOK_LE) || gp_match(p, TOK_GE)) {
        GP_Token* op = gp_advance_tok(p);
        ASTNode* right = gp_parse_addsub(p);
        if (!right) return NULL;
        
        ASTNode* bin = ast_alloc(AST_BINOP, op->line);
        strncpy(bin->binop.op, op->text, 3);
        bin->binop.left = left;
        bin->binop.right = right;
        left = bin;
    }
    
    return left;
}

static ASTNode* gp_parse_and(GP_Parser* p) {
    ASTNode* left = gp_parse_cmp(p);
    if (!left) return NULL;
    
    while (gp_consume(p, TOK_AND)) {
        GP_Token* op = &p->tokens[p->pos - 1];
        ASTNode* right = gp_parse_cmp(p);
        if (!right) return NULL;
        
        ASTNode* bin = ast_alloc(AST_BINOP, op->line);
        strncpy(bin->binop.op, "&&", 3);
        bin->binop.left = left;
        bin->binop.right = right;
        left = bin;
    }
    
    return left;
}

static ASTNode* gp_parse_or(GP_Parser* p) {
    ASTNode* left = gp_parse_and(p);
    if (!left) return NULL;
    
    while (gp_consume(p, TOK_OR)) {
        GP_Token* op = &p->tokens[p->pos - 1];
        ASTNode* right = gp_parse_and(p);
        if (!right) return NULL;
        
        ASTNode* bin = ast_alloc(AST_BINOP, op->line);
        strncpy(bin->binop.op, "||", 3);
        bin->binop.left = left;
        bin->binop.right = right;
        left = bin;
    }
    
    return left;
}

static ASTNode* gp_parse_expr(GP_Parser* p) {
    return gp_parse_or(p);
}

static ASTNode* gp_parse_stmt(GP_Parser* p) {
    GP_Token* t = gp_peek_tok(p);
    
    // Empty line
    if (t->type == TOK_NEWLINE || t->type == TOK_EOF) {
        gp_advance_tok(p);
        return NULL; // skip
    }
    
    // Pass
    if (gp_consume(p, TOK_PASS)) {
        return ast_alloc(AST_PASS, t->line);
    }
    
    // Break
    if (gp_consume(p, TOK_BREAK)) {
        return ast_alloc(AST_BREAK, t->line);
    }
    
    // Continue
    if (gp_consume(p, TOK_CONTINUE)) {
        return ast_alloc(AST_CONTINUE, t->line);
    }
    
    // Return
    if (gp_consume(p, TOK_RETURN)) {
        ASTNode* n = ast_alloc(AST_RETURN, t->line);
        if (!gp_match(p, TOK_NEWLINE) && !gp_match(p, TOK_EOF)) {
            n->ret.value = gp_parse_expr(p);
        }
        return n;
    }
    
    // If
    if (gp_consume(p, TOK_IF)) {
        ASTNode* n = ast_alloc(AST_IF, t->line);
        n->if_stmt.cond = gp_parse_expr(p);
        if (!gp_expect(p, TOK_COLON, "':'")) return NULL;
        if (!gp_expect(p, TOK_NEWLINE, "newline")) return NULL;
        if (!gp_expect(p, TOK_INDENT, "indent")) return NULL;
        
        n->if_stmt.n_then = 0;
        while (!gp_match(p, TOK_DEDENT) && !gp_match(p, TOK_EOF)) {
            int gp_before_pos = p->pos;
            ASTNode* stmt = gp_parse_stmt(p);
            if (stmt && n->if_stmt.n_then < GP_MAX_BLOCK_STMTS) n->if_stmt.then_stmts[n->if_stmt.n_then++] = stmt;
            if (p->pos == gp_before_pos) { gp_error("Parser atascado en linea %d", gp_peek_tok(p)->line); gp_advance_tok(p); }
        }
        gp_consume(p, TOK_DEDENT);
        
        // Else / Elif
        n->if_stmt.n_else = 0;
        n->if_stmt.n_else = 0;
        
        if (gp_consume(p, TOK_ELSE)) {
            if (!gp_expect(p, TOK_COLON, "':'")) return NULL;
            if (!gp_expect(p, TOK_NEWLINE, "newline")) return NULL;
            if (!gp_expect(p, TOK_INDENT, "indent")) return NULL;
            
            while (!gp_match(p, TOK_DEDENT) && !gp_match(p, TOK_EOF)) {
                int gp_before_pos = p->pos;
                ASTNode* stmt = gp_parse_stmt(p);
                if (stmt && n->if_stmt.n_else < GP_MAX_BLOCK_STMTS) n->if_stmt.else_stmts[n->if_stmt.n_else++] = stmt;
                if (p->pos == gp_before_pos) { gp_error("Parser atascado en linea %d", gp_peek_tok(p)->line); gp_advance_tok(p); }
            }
            gp_consume(p, TOK_DEDENT);
        }
        
        return n;
    }
    
    // For
    if (gp_consume(p, TOK_FOR)) {
        GP_Token* var = gp_peek_tok(p);
        if (var->type != TOK_IDENT) {
            gp_error("Line %d: expected variable name in for", var->line);
            return NULL;
        }
        gp_advance_tok(p);
        
        if (!gp_expect(p, TOK_IN, "'in'")) return NULL;
        
        ASTNode* n = ast_alloc(AST_FOR, t->line);
        strncpy(n->for_stmt.var, var->text, 63);
        n->for_stmt.iterable = gp_parse_expr(p);
        if (!gp_expect(p, TOK_COLON, "':'")) return NULL;
        if (!gp_expect(p, TOK_NEWLINE, "newline")) return NULL;
        if (!gp_expect(p, TOK_INDENT, "indent")) return NULL;
        
        n->for_stmt.n_body = 0;
        while (!gp_match(p, TOK_DEDENT) && !gp_match(p, TOK_EOF)) {
            int gp_before_pos = p->pos;
            ASTNode* stmt = gp_parse_stmt(p);
            if (stmt && n->for_stmt.n_body < GP_MAX_BLOCK_STMTS) n->for_stmt.body[n->for_stmt.n_body++] = stmt;
            if (p->pos == gp_before_pos) { gp_error("Parser atascado en linea %d", gp_peek_tok(p)->line); gp_advance_tok(p); }
        }
        gp_consume(p, TOK_DEDENT);
        
        return n;
    }
    
    // While
    if (gp_consume(p, TOK_WHILE)) {
        ASTNode* n = ast_alloc(AST_WHILE, t->line);
        n->while_stmt.cond = gp_parse_expr(p);
        if (!gp_expect(p, TOK_COLON, "':'")) return NULL;
        if (!gp_expect(p, TOK_NEWLINE, "newline")) return NULL;
        if (!gp_expect(p, TOK_INDENT, "indent")) return NULL;
        
        n->while_stmt.n_body = 0;
        while (!gp_match(p, TOK_DEDENT) && !gp_match(p, TOK_EOF)) {
            int gp_before_pos = p->pos;
            ASTNode* stmt = gp_parse_stmt(p);
            if (stmt && n->while_stmt.n_body < GP_MAX_BLOCK_STMTS) n->while_stmt.body[n->while_stmt.n_body++] = stmt;
            if (p->pos == gp_before_pos) { gp_error("Parser atascado en linea %d", gp_peek_tok(p)->line); gp_advance_tok(p); }
        }
        gp_consume(p, TOK_DEDENT);
        
        return n;
    }
    
    // Assignment: x = expr
    if (t->type == TOK_IDENT) {
        // Look ahead for '='
        int saved = p->pos;
        gp_advance_tok(p);
        if (gp_consume(p, TOK_ASSIGN)) {
            ASTNode* n = ast_alloc(AST_ASSIGN, t->line);
            strncpy(n->assign.name, t->text, 63);
            n->assign.value = gp_parse_expr(p);
            return n;
        }
        // Not assignment, backtrack and parse as expression
        p->pos = saved;
    }
    
    // Expression statement
    ASTNode* expr = gp_parse_expr(p);
    if (expr) {
        ASTNode* stmt = ast_alloc(AST_EXPR_STMT, t->line);
        // We can't store expr directly, so we use a trick
        // In practice, expr statements are calls that stand alone
        return expr; // Simplified: expressions ARE statements
    }
    
    return NULL;
}

ASTNode* gp_parse(GP_Token* tokens, int num_tokens) {
    GP_Parser p = { .tokens = tokens, .num_tokens = num_tokens, .pos = 0 };
    
    ASTNode* prog = ast_alloc(AST_PROGRAM, 1);
    prog->program.n_stmts = 0;
    
    while (!gp_match(&p, TOK_EOF)) {
        int gp_before_pos = p.pos;
        ASTNode* stmt = gp_parse_stmt(&p);
        if (stmt) {
            if (prog->program.n_stmts < GP_MAX_BLOCK_STMTS) prog->program.stmts[prog->program.n_stmts++] = stmt;
        }
        // Skip newlines between statements
        while (gp_consume(&p, TOK_NEWLINE));
        if (p.pos == gp_before_pos) {
            gp_error("Parser atascado en linea %d", gp_peek_tok(&p)->line);
            gp_advance_tok(&p);
        }
    }
    
    return prog;
}

// ============================================================
// CODE GENERATOR - Python AST → C Code
// ============================================================

typedef struct {
    char* output;
    size_t size;
    size_t used;
    int indent;
    bool at_line_start;
    char declared_vars[128][64];
    int n_declared;
} GP_Generator;

static bool gp_is_declared(GP_Generator* g, const char* name) {
    for (int i = 0; i < g->n_declared; i++) {
        if (strcmp(g->declared_vars[i], name) == 0) return true;
    }
    return false;
}

static void gp_mark_declared(GP_Generator* g, const char* name) {
    if (g->n_declared < 128) {
        strncpy(g->declared_vars[g->n_declared], name, 63);
        g->n_declared++;
    }
}

static void gp_emit(GP_Generator* g, const char* fmt, ...) {
    if (g->used >= g->size - 1) return;
    
    va_list args;
    va_start(args, fmt);
    
    // Solo indentamos si estamos al inicio de una linea nueva (si no, cada
    // sub-expresion dentro de una misma sentencia iria acumulando espacios).
    if (g->at_line_start) {
        for (int i = 0; i < g->indent; i++) {
            if (g->used < g->size - 1) g->output[g->used++] = ' ';
            if (g->used < g->size - 1) g->output[g->used++] = ' ';
            if (g->used < g->size - 1) g->output[g->used++] = ' ';
            if (g->used < g->size - 1) g->output[g->used++] = ' ';
        }
        g->at_line_start = false;
    }
    
    int n = vsnprintf(g->output + g->used, g->size - g->used, fmt, args);
    if (n > 0) {
        g->used += n;
        if (n > 0 && g->output[g->used - 1] == '\n') g->at_line_start = true;
    }
    
    va_end(args);
}

static void gp_gen_expr(ASTNode* n, GP_Generator* g);

static void gp_gen_expr(ASTNode* n, GP_Generator* g) {
    if (!n) return;
    
    switch (n->type) {
        case AST_CONST:
            if (n->is_string_const) {
                gp_emit(g, "\"%s\"", n->string.str);
            } else {
                gp_emit(g, "%d", n->number.val);
            }
            break;
            
        case AST_VAR:
            gp_emit(g, "%s", n->var.name);
            break;
            
        case AST_CALL: {
            GPBinding* b = gp_find_binding(n->call.name);
            if (!b) {
                gp_emit(g, "/* UNKNOWN: %s */", n->call.name);
                break;
            }
            gp_emit(g, "%s(", b->c_name);
            for (int i = 0; i < n->call.nargs; i++) {
                gp_gen_expr(n->call.args[i], g);
                if (i < n->call.nargs - 1) gp_emit(g, ", ");
            }
            gp_emit(g, ")");
            break;
        }
        
        case AST_METHOD: {
            char full_name[128];
            // Get object name
            const char* obj_name = "";
            if (n->method.obj->type == AST_VAR) {
                obj_name = n->method.obj->var.name;
            }
            snprintf(full_name, sizeof(full_name), "%s.%s", obj_name, n->method.method);
            
            GPBinding* b = gp_find_binding(full_name);
            if (!b) {
                gp_emit(g, "/* UNKNOWN: %s */", full_name);
                break;
            }
            
            // Check if returns void or value
            bool returns_void = (strcmp(b->ret_type, "void") == 0);
            
            if (!returns_void) {
                gp_emit(g, "({ ");
                gp_emit(g, "%s _tmp = ", b->ret_type);
            }
            
            gp_emit(g, "%s(r", b->c_name);
            if (n->method.nargs > 0) gp_emit(g, ", ");
            for (int i = 0; i < n->method.nargs; i++) {
                gp_gen_expr(n->method.args[i], g);
                if (i < n->method.nargs - 1) gp_emit(g, ", ");
            }
            gp_emit(g, ")");
            
            if (!returns_void) {
                gp_emit(g, "; _tmp; })");
            }
            break;
        }
        
        case AST_BINOP:
            gp_emit(g, "(");
            gp_gen_expr(n->binop.left, g);
            gp_emit(g, " %s ", n->binop.op);
            gp_gen_expr(n->binop.right, g);
            gp_emit(g, ")");
            break;
            
        case AST_UNOP:
            gp_emit(g, "(%s", n->unop.op);
            gp_gen_expr(n->unop.operand, g);
            gp_emit(g, ")");
            break;
            
        case AST_LIST: {
            gp_emit(g, "(GP_List){.items = (void*[]) {");
            for (int i = 0; i < n->list.n_items; i++) {
                gp_gen_expr(n->list.items[i], g);
                if (i < n->list.n_items - 1) gp_emit(g, ", ");
            }
            gp_emit(g, "}, .len = %d}", n->list.n_items);
            break;
        }
        
        case AST_INDEX:
            gp_gen_expr(n->index.obj, g);
            gp_emit(g, "[");
            gp_gen_expr(n->index.index, g);
            gp_emit(g, "]");
            break;
            
        default:
            gp_emit(g, "/* UNKNOWN EXPR */");
    }
}

static void gp_gen_stmt(ASTNode* n, GP_Generator* g);

static void gp_gen_stmt(ASTNode* n, GP_Generator* g) {
    if (!n) return;
    
    switch (n->type) {
        case AST_EXPR_STMT:
            // Expressions that are statements (function calls)
            gp_gen_expr(n, g);
            gp_emit(g, ";\n");
            break;
            
        case AST_ASSIGN: {
            if (!gp_is_declared(g, n->assign.name)) {
                gp_emit(g, "int %s = ", n->assign.name);
                gp_mark_declared(g, n->assign.name);
            } else {
                gp_emit(g, "%s = ", n->assign.name);
            }
            gp_gen_expr(n->assign.value, g);
            gp_emit(g, ";\n");
            break;
        }
        
        case AST_IF: {
            gp_emit(g, "if (");
            gp_gen_expr(n->if_stmt.cond, g);
            gp_emit(g, ") {\n");
            g->indent++;
            for (int i = 0; i < n->if_stmt.n_then; i++) {
                gp_gen_stmt(n->if_stmt.then_stmts[i], g);
            }
            g->indent--;
            gp_emit(g, "}\n");
            
            if (n->if_stmt.n_else > 0) {
                gp_emit(g, "else {\n");
                g->indent++;
                for (int i = 0; i < n->if_stmt.n_else; i++) {
                    gp_gen_stmt(n->if_stmt.else_stmts[i], g);
                }
                g->indent--;
                gp_emit(g, "}\n");
            }
            break;
        }
        
        case AST_FOR: {
            // Caso especial (el unico soportado hoy): for VAR in range(N).
            // Se traduce a un for-loop de C plano, sin pasar por GP_List.
            ASTNode* it = n->for_stmt.iterable;
            if (it && it->type == AST_CALL && strcmp(it->call.name, "range") == 0
                && it->call.nargs >= 1 && it->call.nargs <= 2) {
                const char* var = n->for_stmt.var;
                gp_emit(g, "for (int %s = ", var);
                if (it->call.nargs == 2) {
                    gp_gen_expr(it->call.args[0], g); // inicio explicito
                } else {
                    gp_emit(g, "0"); // range(N) empieza en 0
                }
                gp_emit(g, "; %s < ", var);
                gp_gen_expr(it->call.args[it->call.nargs - 1], g); // limite
                gp_emit(g, "; %s++) {\n", var);
                gp_mark_declared(g, var);
                g->indent++;
                for (int i = 0; i < n->for_stmt.n_body; i++) {
                    gp_gen_stmt(n->for_stmt.body[i], g);
                }
                g->indent--;
                gp_emit(g, "}\n");
                break;
            }

            // Iteracion general sobre una lista (GP_List) - caso avanzado.
            gp_emit(g, "{\n");
            g->indent++;
            gp_emit(g, "GP_List* _iter = ");
            gp_gen_expr(n->for_stmt.iterable, g);
            gp_emit(g, ";\n");
            gp_emit(g, "for (size_t _i = 0; _i < _iter->len; _i++) {\n");
            g->indent++;
            gp_emit(g, "GP_Any %s = _iter->items[_i];\n", n->for_stmt.var);
            for (int i = 0; i < n->for_stmt.n_body; i++) {
                gp_gen_stmt(n->for_stmt.body[i], g);
            }
            g->indent--;
            gp_emit(g, "}\n");
            g->indent--;
            gp_emit(g, "}\n");
            break;
        }
        
        case AST_WHILE: {
            gp_emit(g, "while (");
            gp_gen_expr(n->while_stmt.cond, g);
            gp_emit(g, ") {\n");
            g->indent++;
            for (int i = 0; i < n->while_stmt.n_body; i++) {
                gp_gen_stmt(n->while_stmt.body[i], g);
            }
            g->indent--;
            gp_emit(g, "}\n");
            break;
        }
        
        case AST_RETURN:
            gp_emit(g, "return");
            if (n->ret.value) {
                gp_emit(g, " ");
                gp_gen_expr(n->ret.value, g);
            }
            gp_emit(g, ";\n");
            break;
            
        case AST_PASS:
            gp_emit(g, "; /* pass */\n");
            break;
            
        case AST_BREAK:
            gp_emit(g, "break;\n");
            break;
            
        case AST_CONTINUE:
            gp_emit(g, "continue;\n");
            break;
            
        case AST_CALL:
            gp_gen_expr(n, g);
            gp_emit(g, ";\n");
            break;
            
        default:
            gp_emit(g, "/* UNKNOWN STMT */\n");
    }
}

int gp_generate(ASTNode* ast, char* output, size_t size) {
    GP_Generator g = { .output = output, .size = size, .used = 0, .indent = 1, .at_line_start = true };
    
    // Header
    gp_emit(&g, "#include \"gopherpy_runtime.h\"\n\n");
    gp_emit(&g, "void gopherpy_main(void) {\n");
    
    // Body
    for (int i = 0; i < ast->program.n_stmts; i++) {
        gp_gen_stmt(ast->program.stmts[i], &g);
    }
    
    // Footer
    gp_emit(&g, "}\n");
    
    output[g.used] = '\0';
    return g.used;
}

// ============================================================
// PUBLIC API
// ============================================================

int gp_compile(const char* python_source, char* c_output, size_t c_size) {
    // Reset state
    ast_reset();
    
    // 1. Tokenize
    static GP_Token tokens[GP_MAX_TOKENS];
    int n_tokens = gp_tokenize(python_source, tokens, GP_MAX_TOKENS);
    if (n_tokens < 0) return -1;
    
    // 2. Parse
    ASTNode* ast = gp_parse(tokens, n_tokens);
    if (!ast) return -1;
    
    // 3. Validate (check whitelist)
    if (!gp_validate_ast(ast)) return -1;
    
    // 4. Generate C
    int n = gp_generate(ast, c_output, c_size);
    
    return n;
}

// Error handling
static char gp_error_msg[256];
static int gp_error_line = 0;

void gp_error(const char* fmt, ...) {
    va_list args;
    va_start(args, fmt);
    vsnprintf(gp_error_msg, sizeof(gp_error_msg), fmt, args);
    va_end(args);
}

const char* gp_get_error(void) {
    return gp_error_msg;
}

// Validation
bool gp_validate_ast(ASTNode* ast) {
    // TODO: Walk AST and verify all calls are in whitelist
    // For now, accept all
    return true;
}

GPBinding* gp_find_binding(const char* name) {
    for (int i = 0; i < GP_MAX_BINDINGS && bindings[i].py_name; i++) {
        if (strcmp(name, bindings[i].py_name) == 0) {
            return &bindings[i];
        }
    }
    return NULL;
}
