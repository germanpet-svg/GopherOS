// gopherpy_bindings.c - Tabla de bindings REAL de GopherPy -> ABI de GopherOS
//
// Cada entrada mapea un nombre "amigable" en la sintaxis GopherPy a la
// funcion real de gopheros_abi.h que termina llamando (que a su vez es
// un solo "int 0x80"). Nada de librerias intermedias.

#include "gopherpy.h"

GPBinding bindings[] = {
    {"print",        "gos_print",        "void", {"const char*"}, 1,
     "Imprime texto y salta de linea (como el print de Python)"},

    {"print_int",    "gos_print_int",    "void", {"int"}, 1,
     "Imprime un numero entero"},

    {"yield_cpu",    "gos_yield",        "void", {}, 0,
     "Cede la CPU al scheduler cooperativo"},

    {"screen",       "gos_screen_mode",  "void", {"int"}, 1,
     "Cambia el modo de pantalla: 0=texto 80x25, 1=grafico 320x200x256"},

    {"pset",         "gos_pset",         "void", {"int", "int", "int"}, 3,
     "Dibuja un punto: pset(x, y, color)"},

    {"cls_graphics", "gos_cls_graphics", "void", {"int"}, 1,
     "Limpia la pantalla grafica con un color"},

    {"halt",         "gos_exit",         "void", {"int"}, 1,
     "Termina el programa"},

    {NULL, NULL, NULL, {0}, 0, NULL}
};
