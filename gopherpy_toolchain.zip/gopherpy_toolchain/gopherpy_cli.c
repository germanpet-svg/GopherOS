// gopherpy_cli.c - Herramienta de linea de comandos del traductor GopherPy.
// Uso: gopherpy <entrada.py> <salida.c>
// Corre en la maquina de desarrollo (host), no dentro del kernel: el C que
// genera es el que despues se compila con el toolchain freestanding y se
// linkea contra gopheros_abi.h.

#include <stdio.h>
#include <stdlib.h>
#include "gopherpy.h"

int main(int argc, char** argv) {
    if (argc != 3) {
        fprintf(stderr, "Uso: %s <entrada.py> <salida.c>\n", argv[0]);
        return 1;
    }

    FILE* in = fopen(argv[1], "rb");
    if (!in) { fprintf(stderr, "No se pudo abrir '%s'\n", argv[1]); return 1; }
    fseek(in, 0, SEEK_END);
    long len = ftell(in);
    fseek(in, 0, SEEK_SET);
    char* source = (char*)malloc((size_t)len + 1);
    fread(source, 1, (size_t)len, in);
    source[len] = 0;
    fclose(in);

    size_t out_cap = 64 * 1024;
    char* out = (char*)malloc(out_cap);
    int n = gp_compile(source, out, out_cap);

    if (n < 0) {
        fprintf(stderr, "Error de compilacion: %s\n", gp_get_error());
        return 1;
    }

    FILE* outf = fopen(argv[2], "wb");
    if (!outf) { fprintf(stderr, "No se pudo escribir '%s'\n", argv[2]); return 1; }
    fwrite(out, 1, (size_t)n, outf);
    fclose(outf);

    printf("OK: %s -> %s (%d bytes de C generado)\n", argv[1], argv[2], n);
    return 0;
}
