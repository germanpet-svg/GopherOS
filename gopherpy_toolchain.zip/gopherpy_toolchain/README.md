# GopherPy — traductor Python → C nativo para GopherOS

## Qué es esto

Un traductor (no un intérprete) que toma un subconjunto de sintaxis
Python-como y lo compila a C nativo que llama directo a la ABI de GopherOS
(`gopheros_abi.h`: puros `static inline` con un `int 0x80` cada uno, cero
libc, cero librería gráfica). La idea: escribís algo con sintaxis familiar,
pero el binario final en GopherOS es tan liviano y directo como C escrito
a mano — nada de runtime de Python, nada de bytecode, nada de VM.

## De dónde salió y qué le arreglé

El `gopherpy.c`/`gopherpy.h` originales me llegaron de otra sesión/agente:
tenían buena estructura (tokenizer, parser recursivo-descendente, tabla de
bindings, generador de C) pero **nunca se habían compilado ni corrido**.
Encontré y arreglé, en este orden, con evidencia real (no solo lectura):

1. **Tokenizer**: nunca emitía `DEDENT` para líneas en columna 0 (sin
   espacio inicial) — colgaba el parser con cualquier `if/else` o dos
   sentencias seguidas.
2. **Union aliasing en `AST_CONST`**: los literales numéricos y de texto
   compartían la misma memoria (unión), así que `3` se leía como un byte de
   control. Agregado un discriminador explícito (`is_string_const`).
3. **Asignaciones sin declarar**: `x = 5` generaba `x = 5;` en C sin ningún
   `int x;` antes — no compilaba. Ahora se auto-declara en el primer uso.
4. **`for ... in range()` no traducía a nada realista** (dependía de un
   `GP_List`/iterador que no existía) — ahora se traduce a un `for` de C
   plano cuando el iterable es `range(n)`.
5. **El bug más serio**: varios arrays (`then_stmts`, `else_stmts`,
   `for`/`while` body, argumentos de llamada, items de lista) "tomaban
   prestada" memoria del mismo pool de nodos AST reinterpretándola como un
   array de punteros — pero como un puntero pesa menos que un `ASTNode`
   completo, cualquier nodo nuevo asignado después se auto-corrompía. Se
   reemplazó por arrays de tamaño fijo embebidos en cada nodo.
6. **Argumentos de `sys_print(...)` nunca se guardaban** (se reservaba el
   slot pero nunca se escribía el puntero real) — arreglado igual que 5.
7. Límites de tokens (`GP_MAX_TOKENS=128`) insuficientes para un programa
   real de más de unas pocas líneas — subido a 4096, y los arrays grandes
   pasados de stack a `static` para no arriesgar overflow.

Después de estos arreglos, se probó con un programa real de ~25 líneas
(`demo.py`) con variables, `if/else`, `for/range`, y llamadas a la ABI de
video/RTC — compiló a C correcto, y ese C **corrió de verdad en GopherOS**
(ver `demo_generated.c` y el kernel entregado, comando `gopherpy` del shell).

## Archivos

- `gopherpy.h` / `gopherpy.c` — el traductor en sí (tokenizer, parser, codegen).
- `gopherpy_bindings.c` — la tabla real que mapea nombres "Python" (`print`,
  `screen`, `pset`, `yield_cpu`, ...) a funciones reales de `gopheros_abi.h`.
- `gopherpy_cli.c` — la herramienta de línea de comandos (`gopherpy in.py out.c`).
- `demo.py` — el primer programa de GopherOS, en sintaxis GopherPy.
- `demo_generated.c` — el C que generó el traductor para `demo.py` (el mismo
  que ya está integrado y corriendo en el kernel entregado).

## Cómo compilar y usar el traductor (en tu máquina, no en GopherOS)

```bash
gcc gopherpy_cli.c gopherpy.c gopherpy_bindings.c -o gopherpy
./gopherpy demo.py demo_generated.c
cat demo_generated.c
```

## Sintaxis soportada hoy (v1, deliberadamente mínima)

- Variables (enteras), asignación con auto-declaración.
- `if` / `elif` / `else`.
- `for VAR in range(N)` y `for VAR in range(INICIO, N)`.
- `while`.
- Operadores: `+ - * / > < >= <= == != and or not`.
- Literales: números, strings (sin escapes), `True`/`False`/`None`.
- Llamadas a funciones de la tabla de bindings (`print`, `print_int`,
  `screen`, `pset`, `cls_graphics`, `yield_cpu`, `halt`).
- Comentarios con `#`.

No soportado todavía (documentado, no es un secreto): funciones definidas
por el usuario (`def`), diccionarios/listas con operaciones reales, strings
con `+`/formateo, clases. Es un lenguaje de sistemas mínimo a propósito —
el objetivo no es "Python completo", es "sintaxis cómoda para llamar a la
ABI del kernel sin arrastrar librerías".

## Cómo se integra con GopherOS hoy (honesto sobre el estado actual)

GopherOS todavía no tiene un cargador de programas ring3 (ver conversación
sobre "modo multiusuario"). Así que hoy, "correr un programa GopherPy" es:

1. Escribís tu `.py`.
2. Lo traducís a `.c` con esta herramienta (en tu máquina).
3. Ese `.c` se compila **junto con el kernel** (como un archivo más en
   `kernel/`) y se lanza como un hilo cooperativo más (`proc_create`) —
   exactamente igual que `gopherd` o el `shell`.
4. Como ya usa `int 0x80` para todo, el día que haya ring3 de verdad, el
   mismo `.c` generado debería funcionar sin cambios — es la frontera ABI
   la que importa, no el nivel de privilegio en el que corre hoy.

El comando `gopherpy` del shell de GopherOS ya lanza `demo_generated.c`
integrado de esta forma.
