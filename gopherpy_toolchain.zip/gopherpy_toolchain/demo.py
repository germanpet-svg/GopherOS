print("=== GopherPy - primer programa de GopherOS ===")
print("Compilado a C nativo, cero librerias, un solo int 0x80 por syscall")

x = 10
if x > 5:
    print("x es grande")
else:
    print("x es chico")

print("Contando con un for real (range):")
for i in range(5):
    print_int(i)

print("Probando el modo grafico VGA 320x200x256...")
screen(1)
cls_graphics(1)
pset(160, 100, 14)
pset(161, 100, 14)
pset(160, 101, 14)
pset(161, 101, 14)
yield_cpu()
screen(0)

print("Listo. GopherPy funcionando de punta a punta.")
halt(0)
